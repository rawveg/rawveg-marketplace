# Laravel-Cashier-Paddle - Other

**Pages:** 1

---

## Laravel Cashier (Paddle) - Laravel 12.x - The PHP Framework For Web Artisans

**URL:** https://laravel.com/docs/12.x/cashier-paddle

---
