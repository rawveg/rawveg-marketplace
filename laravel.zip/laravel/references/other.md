# Laravel - Other

**Pages:** 1

---

## Installation - Laravel 12.x - The PHP Framework For Web Artisans

**URL:** https://laravel.com/docs/12.x

---
